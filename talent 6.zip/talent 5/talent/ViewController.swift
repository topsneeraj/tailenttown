//
//  ViewController.swift
//  talent
//
//  Created by tops on 1/4/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit


class ViewController: UIViewController ,UINavigationControllerDelegate,UIImagePickerControllerDelegate {

    
    var loginarray:[Any] = []
    
    
    let regx_user = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    let regx_pass = "[A-Za-z0-9]{6,20}"
    
    @IBOutlet weak var txtpass: TextFieldValidator!
    @IBOutlet weak var txtusr: TextFieldValidator!
    @IBOutlet weak var loginbtn: UIButton!

 

    func cursor()
    {
        txtusr.becomeFirstResponder()
        txtusr.tintColor = UIColor.black
        txtpass.tintColor = UIColor.black
    
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cursor();
        loginbtn.layer.borderWidth = 0.5
        loginbtn.clipsToBounds = true
        loginbtn.layer.cornerRadius = 10
 
    
        
   //     self.navigationItem.hidesBackButton = true
        
        txtusr.leftViewMode = .always
        let imgusr = UIImageView(frame: CGRect(x: 10, y: 0, width: 30, height: 30))
        imgusr.image = UIImage(named: "u4.png")
        txtusr.leftView = imgusr
        
        
        txtpass.leftViewMode = .always
        let imgpass = UIImageView(frame: CGRect(x: 10, y: 0, width: 30, height: 30))
        imgpass.image = UIImage(named: "locked32.png")
        txtpass.leftView = imgpass

     
            
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.darkGray.cgColor
        border.frame = CGRect(x: 0, y: txtusr.frame.size.height - width, width:  txtusr.frame.size.width, height: txtusr.frame.size.height)
        
        border.borderWidth = width
        txtusr.layer.addSublayer(border)
        txtusr.layer.masksToBounds = true
        
        
        let border1 = CALayer()
        let width1 = CGFloat(1.0)
        border1.borderColor = UIColor.darkGray.cgColor
        border1.frame = CGRect(x: 0, y: txtpass.frame.size.height - width, width:  txtpass.frame.size.width, height: txtpass.frame.size.height)
        
        border1.borderWidth = width1
        txtpass.layer.addSublayer(border1)
        txtpass.layer.masksToBounds = true
        
        
        validation();
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
    
    func validation() {
        
     txtusr.addRegx(regx_user, withMsg: "Please enter Username..!")
     txtusr.presentInView = self.view
     txtpass.addRegx(regx_pass, withMsg: "Please enter password in between [6-8] char..!")
     txtpass.presentInView = self.view
    
    }
    
    
    
    func login()
    {
        loginarray = []
        let url = URL(string: "http://localhost/talent/login.php")
        var request = URLRequest(url: url!)
        let session = URLSession.shared
        
        let strbody = "email_id=\(txtusr.text!)&user_pass=\(txtpass.text!)"
        let length = strbody.characters.count
        
        
        request.addValue(String(length), forHTTPHeaderField: "Content-length")
        request.httpBody = strbody.data(using: String.Encoding.utf8)
        request.httpMethod = "POST"
        
        
        let task = session.dataTask(with: request, completionHandler: {(data1, responce, err) in
            
            let str = String(data: data1!, encoding: String.Encoding.utf8)
            print(str!)
            
            DispatchQueue.main.async {
                do
                {
                    let arr = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                    
                    for item in arr
                    {
                        self.loginarray.append(item)
                    
                    }
                    
                    print(self.loginarray)
                    if arr.count == 1
                    {
                        
                        
                        let dif = UserDefaults(); // for plist file
                        let email = dif.value(forKey: "email");
                        
                        //through email
                    
                        
                        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
                        let path = documentDirectory.appending("/login.plist")
                        
                        print(path)
                        
                        if(!FileManager().fileExists(atPath: path)){
                            print(path)
                            
                            let data = self.loginarray[0] as! [String:String]
                            
                            
                         //   let data : [String: String] = ["email":email as! String]
                            
                            let someData = NSDictionary(dictionary: data)
                            let isWritten = someData.write(toFile: path, atomically: true)
                            print("is the file created: \(isWritten)")
                            
                            
                        }
                        else
                        {
                            print("file exists")
                        }
                        

                    
                        let home = self.storyboard?.instantiateViewController(withIdentifier: "Home")
                        
                        self.navigationController?.pushViewController(home!, animated: true)
                        
                        print("ok");
                        
                    }
                    else
                    {
                        
                        
                    }
                    
                }
                catch
                {
                    
                }
            }
            
        })
        
        task.resume()
        
    }
    

    @IBAction func directaction(_ sender: Any) {
        let ab = self.storyboard?.instantiateViewController(withIdentifier: "Home")
        
        self.navigationController?.pushViewController(ab!, animated: true)
        

    }
    
    
    @IBAction func loginclick(_ sender: Any) {
        
        if txtusr.validate() && txtpass.validate()
        {
            login()
            print("validation ok")
        }
        else
        {
         print("something wrong..!")
        }
        
    }

    @IBAction func signup(_ sender: Any) {
        
        let next = self.storyboard?.instantiateViewController(withIdentifier: "reg")
        
        self.navigationController?.pushViewController(next!, animated: true)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

