//
//  LoginAs.swift
//  talent
//
//  Created by TOPS on 1/12/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class LoginAs: UIViewController  {

    @IBOutlet weak var Directorbtn: UIButton!
    @IBOutlet weak var Usrbtn: UIButton!
    
    
    
    
    // for check userplist is avialable.
    
    func usrloginplist()
    {
        
        let document = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
        let path = document.appending("/login.plist")
        print(path)
        
        let somedata = NSDictionary(contentsOfFile: path);
        
        
        let fmg = FileManager();
        
        do {
            try
               fmg.removeItem(atPath: path)
        } catch  {
            
            
        }
      
        
        var test = somedata[""]
        
        
        let filemg = FileManager();
        
        if filemg.fileExists(atPath: path) {
            
            
            let ab = self.storyboard?.instantiateViewController(withIdentifier: "Home")
            
            self.navigationController?.pushViewController(ab!, animated: true)
            
        }

    }
    
    // for check directorplist is avialable.
    
    func dirloginplist()
    {
        
        let document = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
        let path = document.appending("/directorlogin.plist")
        print(path)
        
        let somedata = NSDictionary(contentsOfFile: path);
        
        let filemg = FileManager();
        
        if filemg.fileExists(atPath: path) {
            
            
            let ab = self.storyboard?.instantiateViewController(withIdentifier: "Dirhome")
            
            self.navigationController?.pushViewController(ab!, animated: true)
            
        }
        
        
    }

    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.tintColor = UIColor.black
        
        usrloginplist();
        dirloginplist();

    
        Directorbtn.clipsToBounds = true
        Directorbtn.layer.cornerRadius = 10
        
        Usrbtn.clipsToBounds = true
        Usrbtn.layer.cornerRadius = 10
 
        // for shadow
        
        let radius: CGFloat = Usrbtn.frame.width / 2.0 //change it to .height if you need spread for height
        let shadowPath = UIBezierPath(rect: CGRect(x: 0, y: 0, width: 2.1 * radius, height: Usrbtn.frame.height))
        Usrbtn.layer.shadowColor = UIColor.black.cgColor
        Usrbtn.layer.shadowOffset = CGSize(width: 0.4, height: 0.4)  //Here you control x and y
        Usrbtn.layer.shadowOpacity = 0.4
        Usrbtn.layer.shadowRadius = 4.0 //Here your control your blur
        Usrbtn.layer.masksToBounds =  false
        Usrbtn.layer.shadowPath = shadowPath.cgPath
        
        
        let radius1: CGFloat = Directorbtn.frame.width / 2.0 //change it to .height if you need spread for height
        let shadowPath1 = UIBezierPath(rect: CGRect(x: 0, y: 0, width: 2.1 * radius1, height: Directorbtn.frame.height))
        Directorbtn.layer.shadowColor = UIColor.black.cgColor
        Directorbtn.layer.shadowOffset = CGSize(width: 0.4, height: 0.4)  //Here you control x and y
        Directorbtn.layer.shadowOpacity = 0.4
        Directorbtn.layer.shadowRadius = 4.0 //Here your control your blur
        Directorbtn.layer.masksToBounds =  false
        Directorbtn.layer.shadowPath = shadowPath1.cgPath
        
        // Do any additional setup after loading the view.
    }

    @IBAction func Directorclick(_ sender: Any) {
        
        let log = self.storyboard?.instantiateViewController(withIdentifier: "dirlogin")
        
        self.navigationController?.pushViewController(log!, animated: true)
        
    }
 
    
    @IBAction func Usrclick(_ sender: Any) {
        
        let logusr = self.storyboard?.instantiateViewController(withIdentifier: "usrlogin")
        
        self.navigationController?.pushViewController(logusr!, animated: true)
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
