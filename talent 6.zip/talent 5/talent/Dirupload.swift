//
//  Dirupload.swift
//  talent
//
//  Created by TOPS on 2/16/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit
import MobileCoreServices
import AVFoundation

class Dirupload: UIViewController ,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate{

    var url1 = URL(string: "https://www.google.co.in/") ;
    var flag = 0
    
    
    @IBOutlet weak var imgbanner: UIImageView!

    @IBOutlet weak var startdate: TextFieldValidator!
    @IBOutlet weak var enddate: TextFieldValidator!
    @IBOutlet weak var showname: TextFieldValidator!
    @IBOutlet weak var smalldesc: TextFieldValidator!
    
    @IBOutlet weak var donebarbtn: UIBarButtonItem!
    @IBOutlet weak var proceedbtn: UIButton!
    
    let datepicker = UIDatePicker() // for datepicker.
    
    //validation.
    let regx_showname = "[A-Za-z0-9 ]{2,50}"
    let regx_smalldesc = "[A-Za-z0-9 ]{1,10000}"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.getimgdata))
        
        tap.numberOfTapsRequired = 1
        imgbanner.addGestureRecognizer(tap)
        imgbanner.isUserInteractionEnabled = true
        
        proceedbtn.layer.borderWidth = 0.5
        proceedbtn.clipsToBounds = true
        proceedbtn.layer.cornerRadius = 10
        
        validated();
        
        // Do any additional setup after loading the view.
    }
    
    func getimgdata()  {
        
        let alt = UIAlertController(title: "Select Media Types", message: nil, preferredStyle: .actionSheet)
        
        let photo = UIAlertAction(title: "Photo Library", style: .default, handler: {
        action in
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .photoLibrary
            
       //     picker.mediaTypes = [kUTTypeMovie as String as String]
            
            self.flag = 1;
            
            self.present(picker, animated: true, completion: nil)

            
        })
        
        let video = UIAlertAction(title: "Video", style: .default, handler: {
        act in
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .photoLibrary
            
            picker.mediaTypes = [kUTTypeMovie as String as String]
            
            self.flag = 2;
            
            self.present(picker, animated: true, completion: nil)

        
        })
        
        alt.addAction(photo)
        alt.addAction(video)
        
        self.present(alt, animated: true, completion: nil)
        
       
    }
    
    func validated()
    {
     showname.addRegx(regx_showname, withMsg: "Give valid show title..!")
     showname.presentInView = self.view
     smalldesc.addRegx(regx_smalldesc, withMsg: "Enter description of your show..!")
     smalldesc.presentInView = self.view

    }
    
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at: CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        
        return nil
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
       
        if flag == 1
        {
            let vidiourl =  info[UIImagePickerControllerOriginalImage] as! UIImage;
            
            imgbanner.image = vidiourl
        
            // imgbanner.image = info[UIImagePickerControllerOriginalImage] as? UIImage
            
            self.dismiss(animated: true, completion: nil)
        
        }
        else
        {
            
            let vidiourl =  info[UIImagePickerControllerMediaURL] as! URL;
            
            print(vidiourl)
            
            url1 = vidiourl;
            
            do {
                let test =  try Data(contentsOf: vidiourl, options: Data.ReadingOptions.alwaysMapped);
                
                print(test);
                
                
            } catch  {
                
                
                
            }
            
            
            imgbanner.image = getThumbnailImage(forUrl: vidiourl);
            
            // imgbanner.image = info[UIImagePickerControllerOriginalImage] as? UIImage
            
            self.dismiss(animated: true, completion: nil)
            
        
        }
        
      
        
    }
   
    @IBAction func batbtndone(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)

    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    // Startdate textfield.
    @IBAction func startclick(_ sender: Any) {
        
        datepicker.datePickerMode = .date
        let tool = UIToolbar()
        tool.sizeToFit()
    
        let done = UIBarButtonItem(title: "pick", style: .done, target: self, action: #selector(self.donebutton))
        let space = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let space1 = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        tool.setItems([space1,space,done], animated: false)
        
        startdate.inputAccessoryView = tool
        startdate.inputView = datepicker
        
    }

    func donebutton()
    {
        let dt = datepicker.date
        let format = DateFormatter()
        format.dateFormat = "dd-MM-yyyy"
        startdate.text = format.string(from: dt)
        self.view.endEditing(true)
  
    }
 
    
  // enddate textfield.
    @IBAction func endclick(_ sender: Any) {
        
        datepicker.datePickerMode = .date
        let tool = UIToolbar()
        tool.sizeToFit()
        
        let done = UIBarButtonItem(title: "pick", style: .done, target: self, action: #selector(self.done))
        let space = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let space1 = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        tool.setItems([space1,space,done], animated: false)
        
        enddate.inputAccessoryView = tool
        enddate.inputView = datepicker

        
    }
    
    func done()
    {
        let dt = datepicker.date
        let format = DateFormatter()
        format.dateFormat = "dd-MM-yyyy"
        enddate.text = format.string(from: dt)
        self.view.endEditing(true)
    }
  
    
    @IBAction func proceed(_ sender: Any) {
    
        if showname.validate() && smalldesc.validate()
        {
           if flag == 1
           {
            
            do
            {
                let imggata = UIImageJPEGRepresentation(imgbanner.image!, 1.0)
                
                let base64str = imggata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
                
                
                let Url = URL(string: "http://localhost/talent/addshow.php")
                
                let strbody = "show_name=\(showname.text!)&show_startdate=\(startdate.text!)&show_enddate=\(enddate.text!)&small_desc=\(smalldesc.text!)&image=\(base64str)&flag=\(flag)";
                
                let strtest = strbody.addingPercentEscapes(using: String.Encoding.utf8);
                
                var request = URLRequest(url: Url!)
                request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length")
                request.httpBody = strtest?.data(using: String.Encoding.utf8)
                request.httpMethod = "POST"
                
                let session = URLSession.shared
                let datatask = session.dataTask(with: request, completionHandler:{(data1,resp,err) in
                    
                    
                    let strresp = String(data: data1!, encoding: String.Encoding.utf8)
                    print(strresp ?? "ok")
                    
                    DispatchQueue.main.async {
                        
                        if strresp == "done"
                        {
                            let alt = UIAlertController(title: "Confirmation", message: "Your show successfully Added..!", preferredStyle: .alert )
                            
                            let ok = UIAlertAction(title: "Ok", style: .default, handler: {
                                action in
                                
                                self.navigationController?.popViewController(animated: true)
                                
                            })
                            
                            alt.addAction(ok)
                            self.present(alt, animated: true, completion: nil)
                            
                        }
                        else
                        {
                            
                        }
                    }
                    
                })
                
                datatask.resume()
                
                
                
            }
            catch
            {
                
                
            }
            
            
            }
            else
           {
        
            do
            {
   
                print(url1!);
    
                let dt1 = try Data(contentsOf: url1!, options: Data.ReadingOptions.mappedIfSafe)
               
                
                let base64str = dt1.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
                
                let Url = URL(string: "http://localhost/talent/addshow.php")
                
                let strbody = "show_name=\(showname.text!)&show_startdate=\(startdate.text!)&show_enddate=\(enddate.text!)&small_desc=\(smalldesc.text!)&image=\(base64str)&flag=\(flag)";
                
                let strtest = strbody.addingPercentEscapes(using: String.Encoding.utf8);
                
                var request = URLRequest(url: Url!)
                request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length")
                request.httpBody = strtest?.data(using: String.Encoding.utf8)
                request.httpMethod = "POST"
                
                let session = URLSession.shared
                let datatask = session.dataTask(with: request, completionHandler:{(data1,resp,err) in
                    
                    
                    let strresp = String(data: data1!, encoding: String.Encoding.utf8)
                    print(strresp ?? "ok")
                    
                    DispatchQueue.main.async {
                        
                        if strresp == "done"
                        {
                            let alt = UIAlertController(title: "Confirmation", message: "Your show successfully Added..!", preferredStyle: .alert )
                            
                            let ok = UIAlertAction(title: "Ok", style: .default, handler: {
                                action in
                                
                                self.navigationController?.popViewController(animated: true)
                                
                            })
                            
                            alt.addAction(ok)
                            self.present(alt, animated: true, completion: nil)
                            
                        }
                        else
                        {
                            
                        }
                    }
                    
                })
                
                datatask.resume()
                
                
                
            }
            catch
            {
                
                
            }
            
        }
        
    }
    
    
}
    
    @IBAction func backbtnaction(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
