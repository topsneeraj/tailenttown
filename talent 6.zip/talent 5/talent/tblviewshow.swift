//
//  tblviewshow.swift
//  talent
//
//  Created by tops on 2/28/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class tblviewshow: UIViewController , UINavigationControllerDelegate,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tableviews: UITableView!
    
    var arr:[Any] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let url2 = URL(string: "http://localhost/talent/showdirhome.php")
        let urlrq1 = URLRequest(url: url2!)
        let ssn1 = URLSession.shared;
        
        let datatask1 = ssn1.dataTask(with: urlrq1, completionHandler: {
            (data3,resp3, err3) in
            
            do
            {
                self.arr = try JSONSerialization.jsonObject(with: data3!, options: [] ) as! [[String:String]]
                
                DispatchQueue.main.async {
                    
                    self.tableviews.reloadData()
                    
                }
                
            }
            catch
            {
                
            }
            
        })
        datatask1.resume()

        
        
        
        // Do any additional setup after loading the view.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let ccell = tableView.dequeueReusableCell(withIdentifier: "ccell", for: indexPath) as! cellfortblview
        
        // dynamic image download from server.
        
        let dic1 = arr[indexPath.row] as! [String:String]
        let path = dic1["show_banner"]
        
        var fullpath = "http://localhost/talent/"
        fullpath.append(path!);
        
        let urlpath = URL(string: fullpath)
        
        do
        {
            let dtpath = try Data(contentsOf: urlpath!)
            ccell.videoimg.image = UIImage(data: dtpath)
            
            
        }
        catch
        {
        }
        
        ccell.videoname.text = dic1["video_name"]
        
        ccell.videoimg.layer.borderWidth = 0.5
        ccell.videoimg.clipsToBounds = true
        ccell.videoimg.layer.cornerRadius = 3
        
        
        ccell.layer.cornerRadius = 5
        ccell.clipsToBounds = true
        
        return ccell
        
        
    }
    
    

    @IBAction func addbarbtn(_ sender: Any) {
        
        let a = self.storyboard?.instantiateViewController(withIdentifier: "uploadvideo")
        
        self.navigationController?.pushViewController(a!, animated: true)
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
