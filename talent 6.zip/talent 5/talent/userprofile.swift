//
//  userprofile.swift
//  talent
//
//  Created by tops on 1/8/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit


class userprofile: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate {

    @IBOutlet weak var profileimg: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    profileimg.clipsToBounds = true
    self.profileimg.layer.cornerRadius = self.profileimg.frame.size.width / 2
    profileimg.layer.borderColor = UIColor.blue.cgColor
        
        
    
        // Do any additional setup after loading the view.
    }
    
    @IBAction func logout(_ sender: Any) {
        
        
        
        
    }
    @IBAction func editclick(_ sender: Any) {
        
        let pick  = UIImagePickerController()
        pick.delegate = self
        pick.sourceType = .photoLibrary
        
        self.present(pick, animated: true, completion: nil)
        
        
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let  img1 = info[UIImagePickerControllerOriginalImage] as! UIImage
        profileimg.image = img1
        
        self.dismiss(animated: true
            , completion: nil)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
