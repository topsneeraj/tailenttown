//
//  DirectorRegistration.swift
//  talent
//
//  Created by TOPS on 2/7/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class DirectorRegistration: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    

    
    @IBOutlet weak var dfname: TextFieldValidator!
    @IBOutlet weak var dproimg: UIImageView!
    @IBOutlet weak var dreglogin: UIButton!
    @IBOutlet weak var dsignupbtn: UIButton!
    @IBOutlet weak var dpassword: TextFieldValidator!
    @IBOutlet weak var demail: TextFieldValidator!
    @IBOutlet weak var dphone: TextFieldValidator!
    @IBOutlet weak var daddress: TextFieldValidator!
    @IBOutlet weak var dlname: TextFieldValidator!
    
    let regx_dfname = "[A-Za-z]{2,15}"
    let regx_dlname = "[A-Za-z]{2,15}"
    let regx_daddress = "[A-Za-z ]{10,200}"
    let regx_dphone = "[0-9]{10}"
    let regx_demail = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    let regx_dpassword = "[A-Za-z0-9]{8,15}"
    
    func valid()
    {
    dfname.addRegx(regx_dfname, withMsg: "Enter proper first name..")
    dfname.presentInView = self.view
    dlname.addRegx(regx_dlname, withMsg: "Enter proper last name..")
    dlname.presentInView = self.view
    daddress.addRegx(regx_daddress, withMsg: "Enter proper address..")
    daddress.presentInView = self.view
    demail.addRegx(regx_demail, withMsg: "Enter correct email..")
    demail.presentInView = self.view
    dpassword.addRegx(regx_dpassword, withMsg: "Enter proper password..")
    dpassword.presentInView = self.view
    }
    
    func textboxstyle() {
        
        let txtborder = CALayer()
        let txtwidth = CGFloat(1.0)
        txtborder.borderColor = UIColor.darkGray.cgColor
        txtborder.frame = CGRect(x: 0, y: dfname.frame.size.height - txtwidth, width:  dfname.frame.size.width, height: dfname.frame.size.height)
        
        txtborder.borderWidth = txtwidth
        dfname.layer.addSublayer(txtborder)
        dfname.layer.masksToBounds = true
        
        
        let txtborder1 = CALayer()
        let txtwidth1 = CGFloat(1.0)
        txtborder1.borderColor = UIColor.darkGray.cgColor
        txtborder1.frame = CGRect(x: 0, y: dlname.frame.size.height - txtwidth1, width:  dlname.frame.size.width, height: dlname.frame.size.height)
        
        txtborder1.borderWidth = txtwidth1
        dlname.layer.addSublayer(txtborder1)
        dlname.layer.masksToBounds = true
        
        let txtborder2 = CALayer()
        let txtwidth2 = CGFloat(1.0)
        txtborder2.borderColor = UIColor.darkGray.cgColor
        txtborder2.frame = CGRect(x: 0, y: daddress.frame.size.height - txtwidth2, width:  daddress.frame.size.width, height: daddress.frame.size.height)
        
        txtborder2.borderWidth = txtwidth2
        daddress.layer.addSublayer(txtborder2)
        daddress.layer.masksToBounds = true
        
        
        let txtborder31 = CALayer()
        let txtwidth31 = CGFloat(1.0)
        txtborder31.borderColor = UIColor.darkGray.cgColor
        txtborder31.frame = CGRect(x: 0, y: dphone.frame.size.height - txtwidth31, width:  dphone.frame.size.width, height: dphone.frame.size.height)
        
        txtborder31.borderWidth = txtwidth31
        dphone.layer.addSublayer(txtborder31)
        dphone.layer.masksToBounds = true
        
        
        let txtborder3 = CALayer()
        let txtwidth3 = CGFloat(1.0)
        txtborder3.borderColor = UIColor.darkGray.cgColor
        txtborder3.frame = CGRect(x: 0, y: demail.frame.size.height - txtwidth3, width:  demail.frame.size.width, height: demail.frame.size.height)
        
        txtborder3.borderWidth = txtwidth3
        demail.layer.addSublayer(txtborder3)
        demail.layer.masksToBounds = true
        
        
        let txtborder4 = CALayer()
        let txtwidth4 = CGFloat(1.0)
        txtborder4.borderColor = UIColor.darkGray.cgColor
        txtborder4.frame = CGRect(x: 0, y: dpassword.frame.size.height - txtwidth4, width:  dpassword.frame.size.width, height: dpassword.frame.size.height)
        
        txtborder4.borderWidth = txtwidth4
        dpassword.layer.addSublayer(txtborder4)
        dpassword.layer.masksToBounds = true
        
    }
    
    @IBAction func dirsignupaction(_ sender: Any) {
    
    
        if dfname.validate() && dlname.validate() && daddress.validate() && dphone.validate() && demail.validate() && dpassword.validate()
        {
        
            let imggata = UIImageJPEGRepresentation(dproimg.image!, 1.0)
            let base64str = imggata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
            
            let Url = URL(string: "http://localhost/talent/dirreg.php")
            
            let strbody = "user_dfname=\(dfname.text!)&user_dlname=\(dlname.text!)&user_dadd=\(daddress.text!)&user_dmob=\(dphone.text!)&user_demail=\(demail.text!)&user_dpass=\(dpassword.text!)&image=\(base64str!)";
            
            let strtest = strbody.addingPercentEscapes(using: String.Encoding.utf8);
            
            var request = URLRequest(url: Url!)
            request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = strtest?.data(using: String.Encoding.utf8)
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            let datatask = session.dataTask(with: request, completionHandler:{(data1,resp,err) in
                
                
                let strresp = String(data: data1!, encoding: String.Encoding.utf8)
                print(strresp ?? "ok")
                
                DispatchQueue.main.async {
                    
                    if strresp == "done"
                    {
                        
                        let ab = self.storyboard?.instantiateViewController(withIdentifier: "dotp")
                      
                        
                        let dif = UserDefaults();
                        dif.set(self.dphone.text, forKey: "mob")
                        
                        
                        self.navigationController?.pushViewController(ab!, animated: true)
                    }
                    else
                    {
                        
                    }
                }
            
        })
            
            datatask.resume()
            
        }

    }
            
 

    @IBAction func dregloginaction(_ sender: Any) {
       

        
        self.navigationController?.popViewController(animated: true)

        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.hidesBackButton = true
        self.navigationController?.navigationBar.tintColor = UIColor.black
     
        textboxstyle();
        valid();
        cursor();
        
        
        dproimg.clipsToBounds = true
        self.dproimg.layer.cornerRadius = self.dproimg.frame.size.width / 2
        dproimg.layer.borderColor = UIColor.blue.cgColor
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.getimg))
        
        tap.numberOfTapsRequired = 1
        dproimg.addGestureRecognizer(tap)
        dproimg.isUserInteractionEnabled = true
        

        // Do any additional setup after loading the view.
    }

    
    func getimg()  {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        
        self.present(picker, animated: true, completion: nil)

    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        dproimg.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        
        self.dismiss(animated: true, completion: nil)
        
    }
    
    
    func cursor()
    {
        dfname.becomeFirstResponder()
        dfname.tintColor = UIColor.black
        dlname.tintColor = UIColor.black
        daddress.tintColor = UIColor.black
        dphone.tintColor = UIColor.black
        demail.tintColor = UIColor.black
        dpassword.tintColor = UIColor.black
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
