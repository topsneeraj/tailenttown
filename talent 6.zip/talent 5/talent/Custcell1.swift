//
//  Custcell1.swift
//  talent
//
//  Created by tops on 1/17/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class Custcell1: UICollectionViewCell {
    
    @IBOutlet weak var cellimg: UIImageView!
    @IBOutlet weak var celllbl: UILabel!
    
    
    
    
}
