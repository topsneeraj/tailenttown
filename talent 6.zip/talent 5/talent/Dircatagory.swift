//
//  Dircatagory.swift
//  talent
//
//  Created by TOPS on 2/9/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class Dircatagory: UIViewController,UITableViewDelegate,UITableViewDataSource,UINavigationControllerDelegate {

    var array:[Any] = []
    
    @IBOutlet weak var mytableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let url1 = URL(string: "http://localhost/talent/getdircat.php")
        let urlrq = URLRequest(url: url1!)
        let ssn = URLSession.shared;
        
        let datatask1 = ssn.dataTask(with: urlrq, completionHandler: {
            (data2,resp2, err2) in
            
            do
            {
                self.array = try JSONSerialization.jsonObject(with: data2!, options: [] ) as! [[String:String]]
                
                DispatchQueue.main.async {
                    
                    self.mytableview.reloadData()
                    
                }
                
            }
            catch
            {
                
            }
            
        })
        datatask1.resume()
        
        
    // Do any additional setup after loading the view
        
    }
    
    
        

    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let custcell = tableView.dequeueReusableCell(withIdentifier: "dircell", for: indexPath) as! customcell
        
        // dynamic image download from server.
        
        let dic1 = array[indexPath.row] as! [String:String]
        let path = dic1["catimg"]
        
        var fullpath = "http://localhost/talent/"
        fullpath.append(path!);
        
        let urlpath = URL(string: fullpath)
        
        do
        {
            let dtpath = try Data(contentsOf: urlpath!)
            custcell.cellimg.image = UIImage(data: dtpath)

            
        }
        catch
        {
        }
        
        custcell.celllabel.text = dic1["dtype_name"]
        custcell.layer.cornerRadius = 10
        custcell.clipsToBounds = true
        
        custcell.cellimg.layer.cornerRadius = 10
        custcell.cellimg.layer.masksToBounds = true
    
        custcell.accessoryType = .detailDisclosureButton
        
        return custcell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        let dic1 = array[indexPath.row] as! [String:String]
        let cat_id = dic1["dtype_id"]
        
        let dif = UserDefaults();
        let phone = dif.value(forKey: "mob");
        
        
        let url1 = URL(string: "http://localhost/talent/updatedircat.php")
        let strbody = "dir_mob=\(phone!)&dir_id=\(cat_id!)"
        var urlrq = URLRequest(url: url1!)
        urlrq.setValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length");
        urlrq.httpBody = strbody.data(using: String.Encoding.utf8);
        urlrq.httpMethod = "POST"
        
        let ssn = URLSession.shared;
        
        let datatask1 = ssn.dataTask(with: urlrq, completionHandler: {
            (data2,resp2, err2) in
            
            
            let strresp = String(data: data2!, encoding: String.Encoding.utf8)
            print(strresp ?? "ok")
            
            DispatchQueue.main.async {
                
                if strresp == "done"
                {
                    
                    let ab = self.storyboard?.instantiateViewController(withIdentifier: "dirlogin")
                    
                    self.navigationController?.pushViewController(ab!, animated: true)
                    
                }
                else
                {
                    
                }
            }
            
            
        })
        
        datatask1.resume();
    
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
