//
//  registration.swift
//  talent
//
//  Created by tops on 1/8/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class registration: UIViewController ,UIImagePickerControllerDelegate,
UINavigationControllerDelegate{

    
    let regx_fname = "[A-Za-z]{2,15}"
    let regx_lname = "[A-Za-z]{2,15}"
    let regx_add = "[A-Za-z ]{10,200}"
    let regx_phone = "[0-9]{10}"
    let regx_email = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    let regx_pass = "[A-Za-z0-9]{8,15}"
    
    

    @IBOutlet weak var Fname: TextFieldValidator!
    @IBOutlet weak var Lname: TextFieldValidator!
    @IBOutlet weak var Add: TextFieldValidator!
    @IBOutlet weak var phone: TextFieldValidator!
    @IBOutlet weak var email: TextFieldValidator!
    @IBOutlet weak var pass: TextFieldValidator!

    
    @IBOutlet weak var regimg: UIImageView!
    @IBOutlet weak var Signbtn: UIButton!

    
    

    
    
    func getimgdata() {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        
        self.present(picker, animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        regimg.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        
        self.dismiss(animated: true, completion: nil)
        
        
    }
    
    func regvalidation()
    {
    
        Fname.addRegx(regx_fname, withMsg: "Enter proper first name..!")
        Fname.presentInView = self.view
        Lname.addRegx(regx_lname, withMsg: "Enter proper last name..!")
        Lname.presentInView = self.view
        Add.addRegx(regx_add, withMsg: "Enter your address..!")
        Add.presentInView = self.view
        phone.addRegx(regx_phone, withMsg: "Enter valid mobile No...!")
        phone.presentInView = self.view
        email.addRegx(regx_email, withMsg: "Enter valid email address..!")
        email.presentInView = self.view
        pass.addRegx(regx_pass, withMsg: "Password must be in [8-15] char...!")
        pass.presentInView = self.view
    
    }
    
    
    func cursor()
    {
        Fname.becomeFirstResponder()
        Fname.tintColor = UIColor.black
        Lname.tintColor = UIColor.black
        Add.tintColor = UIColor.black
        phone.tintColor = UIColor.black
        email.tintColor = UIColor.black
        pass.tintColor = UIColor.black
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.hidesBackButton = true
        self.navigationController?.navigationBar.tintColor = UIColor.black
       
        regvalidation();
        cursor();

    
        regimg.clipsToBounds = true
        self.regimg.layer.cornerRadius = self.regimg.frame.size.width / 2
        regimg.layer.borderColor = UIColor.blue.cgColor
    
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.getimgdata))
        
        tap.numberOfTapsRequired = 1
        regimg.addGestureRecognizer(tap)
        regimg.isUserInteractionEnabled = true
        

        
        
        
        Signbtn.layer.borderWidth = 0.5
        Signbtn.clipsToBounds = true
        Signbtn.layer.cornerRadius = 10
        
        let txtborder = CALayer()
        let txtwidth = CGFloat(1.0)
        txtborder.borderColor = UIColor.darkGray.cgColor
        txtborder.frame = CGRect(x: 0, y: Fname.frame.size.height - txtwidth, width:  Fname.frame.size.width, height: Fname.frame.size.height)
        
        txtborder.borderWidth = txtwidth
        Fname.layer.addSublayer(txtborder)
        Fname.layer.masksToBounds = true

        
        let txtborder1 = CALayer()
        let txtwidth1 = CGFloat(1.0)
        txtborder1.borderColor = UIColor.darkGray.cgColor
        txtborder1.frame = CGRect(x: 0, y: Lname.frame.size.height - txtwidth1, width:  Lname.frame.size.width, height: Lname.frame.size.height)
        
        txtborder1.borderWidth = txtwidth1
        Lname.layer.addSublayer(txtborder1)
        Lname.layer.masksToBounds = true
        
        let txtborder2 = CALayer()
        let txtwidth2 = CGFloat(1.0)
        txtborder2.borderColor = UIColor.darkGray.cgColor
        txtborder2.frame = CGRect(x: 0, y: Add.frame.size.height - txtwidth2, width:  Add.frame.size.width, height: Add.frame.size.height)
        
        txtborder2.borderWidth = txtwidth2
        Add.layer.addSublayer(txtborder2)
        Add.layer.masksToBounds = true
        
        
        let txtborder31 = CALayer()
        let txtwidth31 = CGFloat(1.0)
        txtborder31.borderColor = UIColor.darkGray.cgColor
        txtborder31.frame = CGRect(x: 0, y: phone.frame.size.height - txtwidth31, width:  phone.frame.size.width, height: phone.frame.size.height)
        
        txtborder31.borderWidth = txtwidth31
        phone.layer.addSublayer(txtborder31)
        phone.layer.masksToBounds = true
        
        
        let txtborder3 = CALayer()
        let txtwidth3 = CGFloat(1.0)
        txtborder3.borderColor = UIColor.darkGray.cgColor
        txtborder3.frame = CGRect(x: 0, y: email.frame.size.height - txtwidth3, width:  email.frame.size.width, height: email.frame.size.height)
        
        txtborder3.borderWidth = txtwidth3
        email.layer.addSublayer(txtborder3)
        email.layer.masksToBounds = true
    
        
        let txtborder4 = CALayer()
        let txtwidth4 = CGFloat(1.0)
        txtborder4.borderColor = UIColor.darkGray.cgColor
        txtborder4.frame = CGRect(x: 0, y: pass.frame.size.height - txtwidth4, width:  pass.frame.size.width, height: pass.frame.size.height)
        
        txtborder4.borderWidth = txtwidth4
        pass.layer.addSublayer(txtborder4)
        pass.layer.masksToBounds = true
        
    
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func regloginbtn(_ sender: Any) {
   //      self.navigationController?.popViewController(animated: true)
 
        self.navigationController?.popViewController(animated: true)
        
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
       }
    
    
    
    @IBAction func signinclick(_ sender: Any) {
        
        if Fname.validate() && Lname.validate() && Add.validate() && phone.validate() && email.validate() && pass.validate()
       {
        
        let imggata = UIImageJPEGRepresentation(regimg.image!, 1.0)
        let base64str = imggata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        
        let Url = URL(string: "http://localhost/talent/registration.php")
        
        let strbody = "user_fname=\(Fname.text!)&user_lname=\(Lname.text!)&user_add=\(Add.text!)&user_mob=\(phone.text!)&user_email=\(email.text!)&user_pass=\(pass.text!)&image=\(base64str!)";
        
        let strtest = strbody.addingPercentEscapes(using: String.Encoding.utf8);
        
        var request = URLRequest(url: Url!)
        request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length")
        request.httpBody = strtest?.data(using: String.Encoding.utf8)
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        let datatask = session.dataTask(with: request, completionHandler:{(data1,resp,err) in
       
        
        let strresp = String(data: data1!, encoding: String.Encoding.utf8)
        print(strresp ?? "ok")

            DispatchQueue.main.async {
                
                if strresp == "done"
                {
               
                let ab = self.storyboard?.instantiateViewController(withIdentifier: "otp")
                 
                    let dif = UserDefaults();
                    dif.set(self.phone.text, forKey: "mob")
                    dif.set(self.email.text, forKey: "email")
                    
                    
                self.navigationController?.pushViewController(ab!, animated: true)
                }
               else
                {
                
                }
            }
       })
        
       datatask.resume()
        
    }

}


    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    


}
