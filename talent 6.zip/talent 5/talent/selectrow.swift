//
//  selectrow.swift
//  talentHunt
//
//  Created by tops on 2/28/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class selectrow: UIViewController,UINavigationControllerDelegate {

    
    var dic : [String:String] = [:];
    
    @IBOutlet weak var showimg: UIImageView!
    @IBOutlet weak var shownm: FloatLabelTextField!
    @IBOutlet weak var showstdate: FloatLabelTextField!
    @IBOutlet weak var showdesc: FloatLabelTextField!
    @IBOutlet weak var showedate: FloatLabelTextField!
    
    func data()
    {
        let path = dic["show_banner"]
        
        var fullpath = "http://localhost/talent/"
        fullpath.append(path!);
        
        let urlpath = URL(string: fullpath)
        
        do
        {
            let dtpath = try Data(contentsOf: urlpath!)
            showimg.image = UIImage(data: dtpath)
            
        }
        catch
        {
        }

        showimg.layer.borderWidth = 0.5
        showimg.clipsToBounds = true
        showimg.layer.cornerRadius = 3
        
        shownm.text = dic["show_name"]
        showstdate.text = dic["show_startdate"]
        showedate.text = dic["show_enddate"]
        showdesc.text = dic["smalldesc"]
    
    }
    
    
    func readonly()
    {
      shownm.isUserInteractionEnabled = false
      showstdate.isUserInteractionEnabled = false
      showedate.isUserInteractionEnabled = false
      showdesc.isUserInteractionEnabled = false
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        data()
        readonly()
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.darkGray.cgColor
        border.frame = CGRect(x: 0, y:  shownm.frame.size.height - width, width:   shownm.frame.size.width, height:  shownm.frame.size.height)
        
        border.borderWidth = width
         shownm.layer.addSublayer(border)
         shownm.layer.masksToBounds = true
        
        
        let border1 = CALayer()
        let width1 = CGFloat(1.0)
        border1.borderColor = UIColor.darkGray.cgColor
        border1.frame = CGRect(x: 0, y: showstdate.frame.size.height - width1, width:  showstdate.frame.size.width, height: showstdate.frame.size.height)
        
        border1.borderWidth = width1
        showstdate.layer.addSublayer(border1)
        showstdate.layer.masksToBounds = true
        
        
        
        let border2 = CALayer()
        let width2 = CGFloat(1.0)
        border2.borderColor = UIColor.darkGray.cgColor
        border2.frame = CGRect(x: 0, y: showedate.frame.size.height - width2, width:  showedate.frame.size.width, height: showedate.frame.size.height)
        
        border2.borderWidth = width2
        showedate.layer.addSublayer(border2)
        showedate.layer.masksToBounds = true
        
        
        let border3 = CALayer()
        let width3 = CGFloat(1.0)
        border3.borderColor = UIColor.darkGray.cgColor
        border3.frame = CGRect(x: 0, y: showdesc.frame.size.height - width3, width:  showdesc.frame.size.width, height: showdesc.frame.size.height)
        
        border3.borderWidth = width3
        showdesc.layer.addSublayer(border3)
        showdesc.layer.masksToBounds = true
        
        
        
        // Do any additional setup after loading the view.
    }

    
    @IBAction func barnackbtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
