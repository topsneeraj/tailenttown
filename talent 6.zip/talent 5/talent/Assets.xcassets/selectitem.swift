//
//  selectitem.swift
//  talent
//
//  Created by TOPS on 2/21/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class selectitem: UIViewController ,UITextFieldDelegate{
    
    var passdic : [String:String] = [:];
    
    let dpicker = UIDatePicker()
    
    
    @IBOutlet weak var donebtn: UIButton!
    @IBOutlet weak var txtsname: FloatLabelTextField!
    @IBOutlet weak var txtedate: FloatLabelTextField!
    @IBOutlet weak var txtsmalldesc: FloatLabelTextField!
    @IBOutlet weak var txtsdate: FloatLabelTextField!

    
    
    @IBOutlet weak var bannerimg: UIImageView!
    
    
    
    func displaydata()
    {
        
        let path = passdic["show_banner"]
        
        var fullpath = "http://localhost/talent/"
        fullpath.append(path!);
        let urlpath = URL(string: fullpath)
        
        do
        {
            let dtpath = try Data(contentsOf: urlpath!)
            bannerimg.image = UIImage(data: dtpath)
        }
        catch
        {
        }

        txtsname.text = passdic["show_name"]
        txtsdate.text = passdic["show_startdate"]
        txtedate.text = passdic["show_enddate"]
        txtsmalldesc.text = passdic["smalldesc"]
        
        bannerimg.layer.borderWidth = 0.5
        bannerimg.clipsToBounds = true
        bannerimg.layer.cornerRadius = 3

        
    }
    
    
    func readonly()
    {
        txtsname.isUserInteractionEnabled = false
        txtsdate.isUserInteractionEnabled = false
        txtedate.isUserInteractionEnabled = false
        txtsmalldesc.isUserInteractionEnabled = false
    }
    
    func editmode()
    {
        txtsname.isUserInteractionEnabled = true
        txtsdate.isUserInteractionEnabled = true
        txtedate.isUserInteractionEnabled = true
        txtsmalldesc.isUserInteractionEnabled = true
    }
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        displaydata()
        readonly()
        
        donebtn.layer.borderWidth = 0.5
        donebtn.clipsToBounds = true
        donebtn.layer.cornerRadius = 10
        
        donebtn.isHidden = true
        
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.darkGray.cgColor
        border.frame = CGRect(x: 0, y: txtsname.frame.size.height - width, width:  txtsname.frame.size.width, height: txtsname.frame.size.height)
        
        border.borderWidth = width
        txtsname.layer.addSublayer(border)
        txtsname.layer.masksToBounds = true
        
        
        let border1 = CALayer()
        let width1 = CGFloat(1.0)
        border1.borderColor = UIColor.darkGray.cgColor
        border1.frame = CGRect(x: 0, y: txtsdate.frame.size.height - width1, width:  txtsdate.frame.size.width, height: txtsdate.frame.size.height)
        
        border1.borderWidth = width1
        txtsdate.layer.addSublayer(border1)
        txtsdate.layer.masksToBounds = true

        
        
        let border2 = CALayer()
        let width2 = CGFloat(1.0)
        border2.borderColor = UIColor.darkGray.cgColor
        border2.frame = CGRect(x: 0, y: txtedate.frame.size.height - width2, width:  txtedate.frame.size.width, height: txtedate.frame.size.height)
        
        border2.borderWidth = width2
        txtedate.layer.addSublayer(border2)
        txtedate.layer.masksToBounds = true
        
        
        let border3 = CALayer()
        let width3 = CGFloat(1.0)
        border3.borderColor = UIColor.darkGray.cgColor
        border3.frame = CGRect(x: 0, y: txtsmalldesc.frame.size.height - width3, width:  txtsmalldesc.frame.size.width, height: txtsmalldesc.frame.size.height)
        
        border3.borderWidth = width3
        txtsmalldesc.layer.addSublayer(border3)
        txtsmalldesc.layer.masksToBounds = true
        
    
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func editclick(_ sender: Any) {
        
    editmode()
    donebtn.isHidden = false
    
    }
    
    @IBAction func donebtnclick(_ sender: Any) {
        
        
        
        
        
    }
    
    @IBAction func backbtn(_ sender: Any) {
    
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    // for edit startdate.
    @IBAction func editstartdate(_ sender: Any) {
        
        dpicker.datePickerMode = .date
        dpicker.backgroundColor = UIColor.white
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
       
        let space1 = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let space2 = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done = UIBarButtonItem(title: "pick", style: .done, target: self, action: #selector(self.dpick))
        
        toolbar.setItems([space1,space2,done], animated: false)
        
        toolbar.isUserInteractionEnabled = true
        txtsdate.inputAccessoryView = toolbar
        txtsdate.inputView = dpicker

        
        
    }

    func dpick() {
        let date = dpicker.date
        let format = DateFormatter()
        format.dateFormat = "dd-MM-yyyy"
        txtsdate.text = format.string(from: date)
        self.view.endEditing(true)
    }
    
    // for edit enddate.
    @IBAction func editenddate(_ sender: Any) {
        
        dpicker.datePickerMode = .date
        dpicker.backgroundColor = UIColor.white
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let space1 = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let space2 = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done = UIBarButtonItem(title: "pick", style: .done, target: self, action: #selector(self.epick))
        
        toolbar.setItems([space1,space2,done], animated: false)
        
        toolbar.isUserInteractionEnabled = true
        txtedate.inputAccessoryView = toolbar
        txtedate.inputView = dpicker

        
    }
    
    func epick()
    {
        let date = dpicker.date
        let format = DateFormatter()
        format.dateFormat = "dd-MM-yyyy"
        txtedate.text = format.string(from: date)
        self.view.endEditing(true)
    
    }

    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
       }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
