//
//  customcell.swift
//  talent
//
//  Created by TOPS on 2/9/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class customcell: UITableViewCell {

    @IBOutlet weak var cellimg: UIImageView!
    @IBOutlet weak var celllabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
