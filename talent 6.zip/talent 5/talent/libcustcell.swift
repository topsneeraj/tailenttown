//
//  libcustcell.swift
//  talent
//
//  Created by TOPS on 2/20/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class libcustcell: UITableViewCell {

    @IBOutlet weak var banner: UIImageView!
    @IBOutlet weak var profileimage: UIImageView!
    @IBOutlet weak var smalldesc: UILabel!
    @IBOutlet weak var showname: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
