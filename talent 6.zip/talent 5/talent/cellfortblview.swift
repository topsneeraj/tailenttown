
//
//  cellfortblview.swift
//  talent
//
//  Created by tops on 2/28/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class cellfortblview: UITableViewCell {

    @IBOutlet weak var videoimg: UIImageView!
    @IBOutlet weak var profilepic: UIImageView!
    @IBOutlet weak var videoname: UILabel!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
