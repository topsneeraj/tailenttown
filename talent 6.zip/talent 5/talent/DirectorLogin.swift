//
//  DirectorLogin.swift
//  talent
//
//  Created by TOPS on 2/7/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class DirectorLogin: UIViewController,UINavigationControllerDelegate {

    var dirloginarr:[Any] = []
    
    
    @IBOutlet weak var dirloginbtn: UIButton!
    @IBOutlet weak var dirpass: TextFieldValidator!
    @IBOutlet weak var dirusrname: TextFieldValidator!
    
    let regx_diruser = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    let regx_dirpass = "[A-Za-z0-9]{6,20}"
    
    func loginvalid()
    {
        dirusrname.addRegx(regx_diruser, withMsg: "Please enter Username..!")
        dirusrname.presentInView = self.view
        dirpass.addRegx(regx_dirpass, withMsg: "Please enter valid password..!")
        dirpass.presentInView = self.view
    }
    
    
    func dirlogin()
    {
        dirloginarr = []
        
        let url = URL(string: "http://localhost/talent/dirlogin.php")
        var request = URLRequest(url: url!)
        let session = URLSession.shared
        
        let strbody = "dir_email=\(dirusrname.text!)&dir_pass=\(dirpass.text!)"
        let length = strbody.characters.count
        
        
        request.addValue(String(length), forHTTPHeaderField: "Content-length")
        request.httpBody = strbody.data(using: String.Encoding.utf8)
        request.httpMethod = "POST"
        
        
        let task = session.dataTask(with: request, completionHandler: {(data1, responce, err) in
            
            let str = String(data: data1!, encoding: String.Encoding.utf8)
            print(str!)
            
            DispatchQueue.main.async {
                do
                {
                    let arr1 = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                    
                    for item in arr1
                    {
                     self.dirloginarr.append(item)
                    }
                    
                    if arr1.count == 1
                    {

                        
                        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
                        let path = documentDirectory.appending("/directorlogin.plist")
                        
                        print(path)
                        
                        if(!FileManager().fileExists(atPath: path)){
                            print(path)
                            
                            
                            let data = self.dirloginarr[0] as! [String:String]
                            
                          //  let data : [String: String] = ["mail":demail as! String]
                            
                            let someData = NSDictionary(dictionary: data)
                            let isWritten = someData.write(toFile: path, atomically: true)
                            print("is the file created: \(isWritten)")
                            
                        }
                        else
                        {
                            print("file exists")
                        }
                        
                        
                        
                        let home = self.storyboard?.instantiateViewController(withIdentifier: "Dirhome")
                        
                        self.navigationController?.pushViewController(home!, animated: true)
                        
                        print("ok");
                        
                    }
                    else
                    {
                        
                        
                    }
                    
                }
                catch
                {
                    
                }
            }
            
        })
        
        task.resume()
        
    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loginvalid();  //validation.
        cursor();      // style.
        
        dirloginbtn.layer.borderWidth = 0.5
        dirloginbtn.clipsToBounds = true
        dirloginbtn.layer.cornerRadius = 10
        
        
        
        //     self.navigationItem.hidesBackButton = true
        
        dirusrname.leftViewMode = .always
        let imgusr = UIImageView(frame: CGRect(x: 10, y: 0, width: 30, height: 30))
        imgusr.image = UIImage(named: "u4.png")
        dirusrname.leftView = imgusr
        
        
        dirpass.leftViewMode = .always
        let imgpass = UIImageView(frame: CGRect(x: 10, y: 0, width: 30, height: 30))
        imgpass.image = UIImage(named: "locked32.png")
        dirpass.leftView = imgpass
        
        
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.darkGray.cgColor
        border.frame = CGRect(x: 0, y: dirusrname.frame.size.height - width, width:  dirusrname.frame.size.width, height: dirusrname.frame.size.height)
        border.borderWidth = width
        dirusrname.layer.addSublayer(border)
        dirusrname.layer.masksToBounds = true
        
        
        let border1 = CALayer()
        let width1 = CGFloat(1.0)
        border1.borderColor = UIColor.darkGray.cgColor
        border1.frame = CGRect(x: 0, y: dirpass.frame.size.height - width, width:  dirpass.frame.size.width, height: dirpass.frame.size.height)
        border1.borderWidth = width1
        dirpass.layer.addSublayer(border1)
        dirpass.layer.masksToBounds = true
        

        // Do any additional setup after loading the view.
    }
    @IBAction func dirsignup(_ sender: Any) {
        let logusr = self.storyboard?.instantiateViewController(withIdentifier: "dregistration")
        
        self.navigationController?.pushViewController(logusr!, animated: true)
    }

    @IBAction func dirlogin(_ sender: Any) {
        
        if dirusrname.validate() && dirpass.validate()
        {
            
            dirlogin();    // login.
            print("ok")

        }
        else
        {
         print("something wrong..!")
        }
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.view.endEditing(true)
    }
    
    
    func cursor()
    {
        dirusrname.becomeFirstResponder()
        dirusrname.tintColor = UIColor.black
        dirpass.tintColor = UIColor.black
        
    }

    @IBAction func directtab(_ sender: Any) {
        
        
        let ab = self.storyboard?.instantiateViewController(withIdentifier: "dircatagory")
        
        self.navigationController?.pushViewController(ab!, animated: true)

        
    }
    
    @IBAction func hme(_ sender: Any) {
        
        let ab = self.storyboard?.instantiateViewController(withIdentifier: "Dirhome")
        
        self.navigationController?.pushViewController(ab!, animated: true)
        

        
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
