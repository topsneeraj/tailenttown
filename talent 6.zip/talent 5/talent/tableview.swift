//
//  tableview.swift
//  talent
//
//  Created by TOPS on 2/20/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class tableview: UIViewController,UITableViewDelegate,UITableViewDataSource,UINavigationControllerDelegate{
    
    @IBOutlet weak var baraddbtn: UIBarButtonItem!
    var arr:[Any] = []
    @IBOutlet weak var librarytblview: UITableView!
    override func viewDidLoad() {
    
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        getdata()
    
        // Do any additional setup after loading the view.
    }

    func getdata()
    {
    
        let url2 = URL(string: "http://localhost/talent/showuserhome.php")
        let urlrq1 = URLRequest(url: url2!)
        let ssn1 = URLSession.shared;
        arr = []
        let datatask1 = ssn1.dataTask(with: urlrq1, completionHandler: {
            (data3,resp3, err3) in
            
            do
            {
                self.arr = try JSONSerialization.jsonObject(with: data3!, options: [] ) as! [[String:String]]
                
                DispatchQueue.main.async {
                    
                    self.librarytblview.reloadData()
                    
                }
                
            }
            catch
            {
                
            }
            
        })
        datatask1.resume()

    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let ccell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! libcustcell
        
        // dynamic image download from server.
        
        
        
        let dic1 = arr[indexPath.row] as! [String:String]
        let path = dic1["show_banner"]
       
        
        
        if path == ""
        {
            
             let vpath = dic1["vurl"]
            var fullpath = "http://localhost/talent/"
            fullpath.append(vpath!);
            
            let url1 = URL(string: fullpath)
            let img1 = getThumbnailImage(forUrl: url1!)
            ccell.banner.image = img1
        
            
        }
        else
        {
        
            var fullpath = "http://localhost/talent/"
            fullpath.append(path!);
            
            let urlpath = URL(string: fullpath)
            
            do
            {
                let dtpath = try Data(contentsOf: urlpath!)
                ccell.banner.image = UIImage(data: dtpath)
                
                
            }
            catch
            {
            }
        
        }
        
        
        ccell.showname.text = dic1["show_name"]
        ccell.smalldesc.text = dic1["smalldesc"]
        
        ccell.banner.layer.borderWidth = 0.5
        ccell.banner.clipsToBounds = true
        ccell.banner.layer.cornerRadius = 3
        
        
        ccell.layer.cornerRadius = 5
        ccell.clipsToBounds = true
        
        return ccell

    }
    
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at: CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        
        return nil
    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        
        
        
        let dic1 = arr[indexPath.row] as! [String:String]
        let path = dic1["show_banner"]
        
        if path == "" {
            
            let vpath = dic1["vurl"]
            var fullpath = "http://localhost/talent/"
            fullpath.append(vpath!);
            
            let videoURL = URL(string: fullpath)
            let player = AVPlayer(url: videoURL!)
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            self.present(playerViewController, animated: true) {
                playerViewController.player!.play()
            }
            
            
            
        }
        else
        {
            let ac = self.storyboard?.instantiateViewController(withIdentifier: "selectview")as! selectitem
            
            let dic1 = arr[indexPath.row] as! [String:String];
            
            ac.passdic =  dic1;
            
            
            self.navigationController?.pushViewController(ac, animated: true)
            
        }
        
        
       
        
    }
    

    @IBAction func addbtnclick(_ sender: Any) {
        
        let ac = self.storyboard?.instantiateViewController(withIdentifier: "upload")
        self.navigationController?.pushViewController(ac!, animated: true)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
          getdata()
          librarytblview.reloadData()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
