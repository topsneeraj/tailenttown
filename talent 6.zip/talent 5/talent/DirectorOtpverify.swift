//
//  DirectorOtpverify.swift
//  talent
//
//  Created by TOPS on 2/7/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class DirectorOtpverify: UIViewController {

    @IBOutlet weak var dotp1: UITextField!
    @IBOutlet weak var dotp2: UITextField!
    @IBOutlet weak var dotp3: UITextField!
    @IBOutlet weak var dotp4: UITextField!
    
    
    func textboxst()  {
        let borderotp1 = CALayer()
        let widthotp1 = CGFloat(1.0)
        borderotp1.borderColor = UIColor.darkGray.cgColor
        borderotp1.frame = CGRect(x: 0, y: dotp1.frame.size.height - widthotp1, width:  dotp1.frame.size.width, height: dotp1.frame.size.height)
        
        borderotp1.borderWidth = widthotp1
        dotp1.layer.addSublayer(borderotp1)
        dotp1.layer.masksToBounds = true
        
        
        
        let borderotp2 = CALayer()
        let widthotp2 = CGFloat(1.0)
        borderotp2.borderColor = UIColor.darkGray.cgColor
        borderotp2.frame = CGRect(x: 0, y: dotp2.frame.size.height - widthotp2, width:  dotp2.frame.size.width, height: dotp2.frame.size.height)
        
        borderotp2.borderWidth = widthotp2
        dotp2.layer.addSublayer(borderotp2)
        dotp2.layer.masksToBounds = true
        
        
        let borderotp3 = CALayer()
        let widthotp3 = CGFloat(1.0)
        borderotp3.borderColor = UIColor.darkGray.cgColor
        borderotp3.frame = CGRect(x: 0, y: dotp3.frame.size.height - widthotp3, width:  dotp3.frame.size.width, height: dotp3.frame.size.height)
        
        borderotp3.borderWidth = widthotp3
        dotp3.layer.addSublayer(borderotp3)
        dotp3.layer.masksToBounds = true
        
        
        
        let borderotp4 = CALayer()
        let widthotp4 = CGFloat(1.0)
        borderotp4.borderColor = UIColor.darkGray.cgColor
        borderotp4.frame = CGRect(x: 0, y: dotp4.frame.size.height - widthotp4, width:  dotp4.frame.size.width, height: dotp4.frame.size.height)
        
        borderotp4.borderWidth = widthotp4
        dotp4.layer.addSublayer(borderotp4)
        dotp4.layer.masksToBounds = true
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textboxst();
        cursor()
        
    
        // Do any additional setup after loading the view.
    }
    
    
    func cursor() {
        
        dotp1.becomeFirstResponder();
        dotp1.tintColor = UIColor.black
        dotp2.tintColor = UIColor.black
        dotp3.tintColor = UIColor.black
        dotp4.tintColor = UIColor.black
    }
    
    
    @IBAction func daction1(_ sender: Any) {
        
        if dotp1.text?.characters.count == 1
        {
         dotp2.becomeFirstResponder()
        }
        
    }
    
    @IBAction func daction2(_ sender: Any) {
        
        if dotp2.text?.characters.count == 1
        {
            dotp3.becomeFirstResponder()
        }
        
    }
    
    @IBAction func daction3(_ sender: Any) {
        
        if dotp3.text?.characters.count == 1
        {
            dotp4.becomeFirstResponder()
        }
        
    }
    
    @IBAction func daction4(_ sender: Any) {
       
        if dotp4.text?.characters.count == 1
        {
           
            let logusr = self.storyboard?.instantiateViewController(withIdentifier: "dircatagory")
            
            self.navigationController?.pushViewController(logusr!, animated: true)

        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
