//
//  custhomecell.swift
//  talent
//
//  Created by TOPS on 2/19/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class custhomecell: UITableViewCell {

    @IBOutlet weak var bannerimg: UIImageView!
    @IBOutlet weak var profileimg: UIImageView!
    @IBOutlet weak var showname: UILabel!
    @IBOutlet weak var smalldesc: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
