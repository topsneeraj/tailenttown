//
//  CollectionView.swift
//  talent
//
//  Created by tops on 1/17/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class CollectionView: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UINavigationControllerDelegate
     {
    
    var finalarr : [Any] = [];
    
    @IBOutlet weak var mycollection: UICollectionView!
    
    
 //   let arr:[String] = ["music.png","dance.png","comedy.png","writer.png","Actor_Male.png","photography.png","sing.png",""]
 //   let arrstr:[String] = ["Musician","Dancer","Comedian","Writer","Actor","Photographer","Singer",""]
    
    override func viewDidLoad() {
        super.viewDidLoad()



        
        // Do any additional setup after loading the view.
        
        let url1 = URL(string: "http://localhost/talent/getcat.php")
        let urlrq = URLRequest(url: url1!)
        let ssn = URLSession.shared;
        
        let datatask1 = ssn.dataTask(with: urlrq, completionHandler: {
            (data2,resp2, err2) in
            
            do
            {
                self.finalarr = try JSONSerialization.jsonObject(with: data2!, options: [] ) as! [[String:String]]
                
                DispatchQueue.main.async {
                    
                    self.mycollection.reloadData()
                    
                }
                
            }
            catch
            {
            
            }
            
    })
        datatask1.resume()
    
}

    
    
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
       
        return 1
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return finalarr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! Custcell1

    
        // dynamic image download from server.
        
        let dic1 = finalarr[indexPath.row] as! [String:String]
        let path = dic1["cat_img"]
        
        var fullpath = "http://localhost/talent/"
        fullpath.append(path!);
        
        let urlpath = URL(string: fullpath)
        
        do
        {
            let dtpath = try Data(contentsOf: urlpath!)
            cell.cellimg.image = UIImage(data: dtpath)
            
        
        }
        catch
        {
        }
        
        
   //     cell.cellimg.image = UIImage(named: arr[indexPath.row])
        
        cell.celllbl.text = dic1["cat_name"]
        cell.backgroundColor = UIColor.white
        cell.layer.shadowColor = UIColor.gray.cgColor
        cell.layer.shadowOffset = CGSize(width: 3, height: 3)
        cell.layer.shadowOpacity = 0.7
        cell.layer.shadowRadius = 4.0
 
        cell.layer.cornerRadius = 7
        cell.clipsToBounds = true
        cell.layer.masksToBounds = false
        
        return cell
        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        let dic1 = finalarr[indexPath.row] as! [String:String]
        let cat_id = dic1["cat_id"]
        
        let dif = UserDefaults();
        let mob = dif.value(forKey: "mob");
        
        
        let url1 = URL(string: "http://localhost/talent/updatecat.php")
        let strbody = "user_mob=\(mob!)&cat_id=\(cat_id!)"
        var urlrq = URLRequest(url: url1!)
        urlrq.setValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length");
        urlrq.httpBody = strbody.data(using: String.Encoding.utf8);
        urlrq.httpMethod = "POST"
        
        let ssn = URLSession.shared;
        
        let datatask1 = ssn.dataTask(with: urlrq, completionHandler: {
            (data2,resp2, err2) in
            
            
            let strresp = String(data: data2!, encoding: String.Encoding.utf8)
            print(strresp ?? "ok")
            
            DispatchQueue.main.async {
                
                if strresp == "done"
                {
            
                    let ab = self.storyboard?.instantiateViewController(withIdentifier: "Home")
                
                    self.navigationController?.pushViewController(ab!, animated: true)
                    
                }
                else
                {
                    
                }
            }

  
        })
        
        datatask1.resume();
        
    }
    
    
    func open()
    {
   
        let openpage = self.storyboard?.instantiateViewController(withIdentifier: "Home")
        
        self.navigationController?.pushViewController(openpage!, animated: true)
    
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
