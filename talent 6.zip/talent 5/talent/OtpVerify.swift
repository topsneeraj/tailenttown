//
//  OtpVerify.swift
//  talent
//
//  Created by TOPS on 1/12/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class OtpVerify: UIViewController {

    @IBOutlet weak var opttxt1: UITextField!
    @IBOutlet weak var opttxt2: UITextField!

    @IBOutlet weak var opttxt3: UITextField!
    @IBOutlet weak var opttxt4: UITextField!
    
    
    @IBOutlet weak var vrfybtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        cursor();
        
        let borderotp1 = CALayer()
        let widthotp1 = CGFloat(1.0)
        borderotp1.borderColor = UIColor.darkGray.cgColor
        borderotp1.frame = CGRect(x: 0, y: opttxt1.frame.size.height - widthotp1, width:  opttxt1.frame.size.width, height: opttxt1.frame.size.height)
        
        borderotp1.borderWidth = widthotp1
        opttxt1.layer.addSublayer(borderotp1)
        opttxt1.layer.masksToBounds = true
        
        
        
        let borderotp2 = CALayer()
        let widthotp2 = CGFloat(1.0)
        borderotp2.borderColor = UIColor.darkGray.cgColor
        borderotp2.frame = CGRect(x: 0, y: opttxt2.frame.size.height - widthotp2, width:  opttxt2.frame.size.width, height: opttxt2.frame.size.height)
        
        borderotp2.borderWidth = widthotp2
        opttxt2.layer.addSublayer(borderotp2)
        opttxt2.layer.masksToBounds = true
        
        
        let borderotp3 = CALayer()
        let widthotp3 = CGFloat(1.0)
        borderotp3.borderColor = UIColor.darkGray.cgColor
        borderotp3.frame = CGRect(x: 0, y: opttxt3.frame.size.height - widthotp3, width:  opttxt3.frame.size.width, height: opttxt3.frame.size.height)
        
        borderotp3.borderWidth = widthotp3
        opttxt3.layer.addSublayer(borderotp3)
        opttxt3.layer.masksToBounds = true
        
        
        
        let borderotp4 = CALayer()
        let widthotp4 = CGFloat(1.0)
        borderotp4.borderColor = UIColor.darkGray.cgColor
        borderotp4.frame = CGRect(x: 0, y: opttxt4.frame.size.height - widthotp4, width:  opttxt4.frame.size.width, height: opttxt4.frame.size.height)
        
        borderotp4.borderWidth = widthotp4
        opttxt4.layer.addSublayer(borderotp4)
        opttxt4.layer.masksToBounds = true
        
        
        
        
        
        vrfybtn.clipsToBounds = true
        vrfybtn.layer.cornerRadius = 10
        
        // Do any additional setup after loading the view.
    }
    
    
    func cursor() {
        
        opttxt1.becomeFirstResponder();
        opttxt1.tintColor = UIColor.black
        opttxt2.tintColor = UIColor.black
        opttxt3.tintColor = UIColor.black
        opttxt4.tintColor = UIColor.black
    }
    

/*    @IBAction func verifyclick(_ sender: Any) {
        
        
        let alt = UIAlertController(title: "Confirmation", message: "Successful Authenticate..!", preferredStyle: .alert )

        let ok = UIAlertAction(title: "Ok", style: .default, handler: {
        
        action in
        
        
            let goto = self.storyboard?.instantiateViewController(withIdentifier: "catagory")
            
            self.navigationController?.pushViewController(goto!, animated: true)

            
        })
        
        alt.addAction(ok)
        self.present(alt, animated: true, completion: nil)
    
    }
     
 */
    
    @IBAction func txt1click(_ sender: Any) {
        
        
        if opttxt1.text?.characters.count == 1
        {
         opttxt2.becomeFirstResponder()
        }
        
        
    }
    @IBAction func txt2click(_ sender: Any) {
        
        if opttxt2.text?.characters.count == 1
        {
          opttxt3.becomeFirstResponder()
        }
    }
    
    @IBAction func txt3click(_ sender: Any) {
        
        if opttxt3.text?.characters.count == 1
        {
        opttxt4.becomeFirstResponder()
        }
    }
    
    @IBAction func txt4click(_ sender: Any) {
        
        if opttxt4.text?.characters.count == 1
        {
        
            let alt = UIAlertController(title: "Confirmation", message: "Successful Authenticate..!", preferredStyle: .alert )
            
            let ok = UIAlertAction(title: "Ok", style: .default, handler: {
                
                action in
                
                
                let goto = self.storyboard?.instantiateViewController(withIdentifier: "catagory")
                
                self.navigationController?.pushViewController(goto!, animated: true)
                
                
            })
            
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
            

            
        }
        
    }
    
   
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.view.endEditing(true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
