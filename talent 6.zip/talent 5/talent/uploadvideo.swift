//
//  uploadvideo.swift
//  talent
//
//  Created by tops on 2/28/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit
import MobileCoreServices
import AVFoundation

class uploadvideo: UIViewController ,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    
     var url1 = URL(string: "https://www.google.co.in/") ;

    @IBOutlet weak var prcbtn: UIButton!
    
    @IBOutlet weak var txtvideoname: TextFieldValidator!
    
    @IBOutlet weak var videoview: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.getimgdata))
        
        tap.numberOfTapsRequired = 1
        videoview.addGestureRecognizer(tap)
        videoview.isUserInteractionEnabled = true
        
        prcbtn.layer.borderWidth = 0.5
        prcbtn.clipsToBounds = true
        prcbtn.layer.cornerRadius = 10


        // Do any additional setup after loading the view.
    }

    func getimgdata() {
        
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        
        picker.mediaTypes = [kUTTypeMovie as String as String]
        
        self.present(picker, animated: true, completion: nil)
        
    }
    
    
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at: CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        
        return nil
    }
    

    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        
        let vidiourl =  info[UIImagePickerControllerMediaURL] as! URL;
        
        print(vidiourl)
        
        url1 = vidiourl;
        
        do {
            let test =  try Data(contentsOf: vidiourl, options: Data.ReadingOptions.alwaysMapped);
            
            print(test);
            
        }
        catch
        {
            
        }
        
        videoview.image = getThumbnailImage(forUrl: vidiourl);
    
        // imgbanner.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        
        self.dismiss(animated: true, completion: nil)
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.view.endEditing(true)
    }

    @IBAction func barbackbtn(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)

        
    }
    
    
    
    @IBAction func proceedbtn(_ sender: Any) {
        
        do
        {
            
            print(url1!);
            
            let dt1 = try Data(contentsOf: url1!, options: Data.ReadingOptions.mappedIfSafe)
            
            
            let base64str = dt1.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
            
            let Url = URL(string: "http://localhost/talent/addvideo.php")
            
            let strbody = "video_name=\(txtvideoname.text!)&image=\(base64str)";
            
            let strtest = strbody.addingPercentEscapes(using: String.Encoding.utf8);
            
            var request = URLRequest(url: Url!)
            request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = strtest?.data(using: String.Encoding.utf8)
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            let datatask = session.dataTask(with: request, completionHandler:{(data1,resp,err) in
                
                
                let strresp = String(data: data1!, encoding: String.Encoding.utf8)
                print(strresp ?? "ok")
                
                DispatchQueue.main.async {
                    
                    if strresp == "done"
                    {
                        let alt = UIAlertController(title: "Confirmation", message: "Your show successfully Added..!", preferredStyle: .alert )
                        
                        let ok = UIAlertAction(title: "Ok", style: .default, handler: {
                            action in
                            
                            self.navigationController?.popViewController(animated: true)
                            
                        })
                        
                        alt.addAction(ok)
                        self.present(alt, animated: true, completion: nil)
                        
                    }
                    else
                    {
                        
                    }
                }
                
            })
            
            datatask.resume()
            
            
            
        }
        catch
        {
            
            
        }
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
