//
//  usritemhome.swift
//  talent
//
//  Created by TOPS on 2/19/18.
//  Copyright © 2018 tops. All rights reserved.
//

import UIKit

class usritemhome: UIViewController,UITableViewDelegate,UITableViewDataSource,UINavigationControllerDelegate {
    
    @IBOutlet weak var searchbtn: UIBarButtonItem!
    @IBOutlet weak var sharebtn: UIBarButtonItem!
    @IBOutlet weak var usrtableview: UITableView!
    
    var usrarry:[Any] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        
        usrtableview.layer.backgroundColor = UIColor.black.cgColor
        let url2 = URL(string: "http://localhost/talent/showuserhome.php")
        let urlrq1 = URLRequest(url: url2!)
        let ssn1 = URLSession.shared;
        
        let datatask1 = ssn1.dataTask(with: urlrq1, completionHandler: {
            (data3,resp3, err3) in
            
            do
            {
                self.usrarry = try JSONSerialization.jsonObject(with: data3!, options: [] ) as! [[String:String]]
                
                DispatchQueue.main.async {
                    
                    self.usrtableview.reloadData()
                    
                }
                
            }
            catch
            {
                
            }
            
        })
        datatask1.resume()
        
        // Do any additional setup after loading the view.
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return usrarry.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let ccell = tableView.dequeueReusableCell(withIdentifier: "homecell", for: indexPath) as! custhomecell
        
        // dynamic image download from server.
        
        let dic1 = usrarry[indexPath.row] as! [String:String]
        let path = dic1["show_banner"]
        
        var fullpath = "http://localhost/talent/"
        fullpath.append(path!);
        
        let urlpath = URL(string: fullpath)
        
        do
        {
            let dtpath = try Data(contentsOf: urlpath!)
            ccell.bannerimg.image = UIImage(data: dtpath)
            
            
        }
        catch
        {
        }
        
        ccell.showname.text = dic1["show_name"]
        ccell.smalldesc.text = dic1["smalldesc"]
        
        ccell.bannerimg.layer.borderWidth = 0.5
        ccell.bannerimg.clipsToBounds = true
        ccell.bannerimg.layer.cornerRadius = 3
        
        
        ccell.layer.cornerRadius = 5
        ccell.clipsToBounds = true

        return ccell

        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let b = self.storyboard?.instantiateViewController(withIdentifier: "selectshow") as! selectrow
        
        let dic1 = usrarry[indexPath.row] as! [String:String];
        
        b.dic =  dic1;
        
        self.navigationController?.pushViewController(b, animated: true)
        
        
    }
    
    
    
    @IBAction func sharebtn(_ sender: Any) {
        
        let arr:[Any] = ["Talent Hunt"]
        let act = UIActivityViewController(activityItems: arr, applicationActivities: nil)
        
        self.present(act, animated: true, completion: nil)

    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
